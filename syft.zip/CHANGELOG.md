### Added Features

- Modify RpmDBEntry to include modularityLabel for cyclonedx [[#4212](https://github.com/anchore/syft/pull/4212) @sfc-gh-rmaj]
- Add locations onto packages read from Java native image SBOMs [[#4186](https://github.com/anchore/syft/pull/4186) @rudsberg]

**[(Full Changelog)](https://github.com/anchore/syft/compare/v1.32.0...v1.33.0)**
